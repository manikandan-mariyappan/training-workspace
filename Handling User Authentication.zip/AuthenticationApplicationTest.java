
package com.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import com.bean.User;
import com.service.UserService;

@SpringBootTest
class AuthenticationApplicationTest {
	
	@Autowired
    UserService userservice;
	@Test
	void contextLoads() {
	}

	
	@Test
	void testServiceCall() {
		Iterable<User> users = userservice.GetAllUsers();
		Integer count = 0;
		
		for(User u: users)
			count++;
		
		assertNotEquals(count, 0);
	}
	
	@Test
	void countUsers() {
		Iterable<User> users = userservice.GetAllUsers();
		Integer count = 0;
		
		for(User u: users)
			count++;
		
		assertEquals(count, 3);
	}
	
	@Test
	void checkAllUsers() {
		Iterable<User> users = userservice.GetAllUsers();
		
		for(User u: users)
			assertNotNull(u);
	} }
