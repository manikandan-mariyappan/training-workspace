package com.service;




	import java.util.Optional;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;

	import com.Exception.UserNotFoundException;
	import com.bean.User;
	import com.dao.UserDao;

	@Service
	public class UserService {
		
		@Autowired
		UserDao userdao;
		
		 public Iterable<User> GetAllUsers()
		    {
		        return userdao.findAll();
		    }


		    public User GetUserByName(String name) {
		        User foundUser = userdao.findByName(name);
		        return foundUser;
		    }
		    
		    public User GetUserById(int id) {
		    	Optional<User> foundUser = userdao.findById(id);
		    	
		    	
		    	//TODO: we need to decide how to handle a "Not Found" condition
		    	
		    	if (!foundUser.isPresent()) {
		    		throw new UserNotFoundException();
		    	}
		    	
		    	return(foundUser.get());
		    }
		    
		    public void UpdateUser(User usertoUpdate) {
		    	userdao.save(usertoUpdate);
		    }
	}	



