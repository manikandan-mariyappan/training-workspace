
  
class CreateNewFile {
    public static void main(String[] args)
    {
  
        // File name specified
        
          System.out.println("File Created!");
    }
}


  
    
   
     

     