
public class TextFile {

	{   

	           
	                
	            
	    }
	    public static void main(String[] args)
	    {
	        TextFile("c://temp//testFile2.txt", "85", "95");
	        System.out.println("done");
	    
	}
		private static void TextFile(String string, String string2, String string3) {
		
			
		}

}
