package com.cont;



	import org.springframework.boot.web.servlet.error.ErrorController;
	import org.springframework.web.bind.annotation.RequestMapping;

	public class AppErrorControllers {

		@RequestMapping("/error")
	    public String handleError() {
	        //do something like logging
	        return "error";
	    }

	    public String getErrorPath() {
	        return null;
	    }
	}

