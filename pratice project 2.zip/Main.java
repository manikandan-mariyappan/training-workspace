public class Main {
   public static void main(String[] args) {
       int a;
       int b;
       int c;
       a = 8;
       b = 5;
       c = a*b; //integer number to keep the result of multiplication
       System.out.println("8*5 = " + c);
   }
}