package com;

public class Operations {

	public static void main(String[] args) {
		   {
		      float a, b, res = 0;
		      int choice;
		      
		      System.out.println("1. Addition");
		      System.out.println("2. Subtraction");
		      System.out.println("3. Multiplication");
		      System.out.println("4. Division");
		      System.out.print("Enter Your Choice (1-4): ");
		      

		      {
		         System.out.print("\nEnter any Two Number: ");
		        
		         
		         System.out.println("\nResult = ");
		      }
		         System.out.println("\nInvalid Choice!");
		   } 
		}

	}
