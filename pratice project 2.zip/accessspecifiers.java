package defaultprotected;

public class accessspecifiers {

	public static void main(String[] args) {

		  display();
		    { 
		        System.out.println("This is protected access specifier"); 
		    } 


	}

	private static void display() {
		
		
	}

}
