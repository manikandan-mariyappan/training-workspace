package publicaccess;

public class publicspecifiers2 {

	public static void main(String[] args) {

			display();
		      { 
		        System.out.println("This is Public Access Specifier"); }
		      } 
		    
		    
            private static void display() {
		    	
		    	
		    }	
		    	
		   }


