import java.util.Scanner;
public class NullPointer {

	public static void main(String[] args) {
		
		System.out.println("enter a number");
		Scanner scan = new Scanner(System.in);
		System.out.println(scan.nextInt());
		
		
		

	}

}
